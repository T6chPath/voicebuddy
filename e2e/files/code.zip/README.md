# Zip project
Run main.py